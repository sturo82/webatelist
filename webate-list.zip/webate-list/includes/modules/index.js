// Internal Dependencies
import WebateList from './WebateList/WebateList';

export default [
    WebateList,
];